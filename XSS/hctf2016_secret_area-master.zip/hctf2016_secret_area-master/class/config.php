<?php
	$config['hostname'] = 'localhost';
	$config['username'] = 'hctf2016_web2';
	$config['password'] = 'wOyyJrYBP3BvEpD3';
	$config['database'] = 'hctf2016_web2';

	$db = new mysqli($config['hostname'],$config['username'],$config['password'],$config['database']);
?>
