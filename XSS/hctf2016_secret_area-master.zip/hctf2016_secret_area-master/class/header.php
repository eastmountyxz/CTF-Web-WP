<?php
	require('class.php');
?>

<!DOCTYPE html>
<html>
<head>
	<title>神秘的聊天板</title>
	<link rel="stylesheet" href="./static/css/bootstrap.min.css">
	<link rel="stylesheet" href="./static/css/default.css">
	<link rel="stylesheet" href="./static/css/styles.css">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>