# hctf2016_secret_area

题目主要思路是通过重定向绕过CSP的目录限制，但是站功能一多了难免就遇到了各种问题，已知有4种解法，所以后面会专门整理wp
请关注
[http://lorexxar.cn](http://lorexxar.cn)
