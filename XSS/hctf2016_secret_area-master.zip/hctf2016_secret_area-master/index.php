<?php
	require('class/header.php');
?>
<div class="container">
<div class="row">
                <div class="col-md-8 col-md-offset-2 text-center inner">
                  <h1 class="white">神秘的聊天板</h1>
                  <h2 class="animated fadeInUp delay-05s white">Just find something</h2>
                </div>
</div>
<div class="row" style="max-width:300px; margin-left: auto; margin-right: auto;">
	<div class="col-md-6 text-center animated fadeInUp delay-15s button">
                  <a href="login.php" class="learn-more-btn">  Login  </a>
                </div>
	<div class="col-md-6 text-center animated fadeInUp delay-15s button">
			        <a href="register.php" class="learn-more-btn">Register</a>
                </div>
</div>
</div>

<?php
	require('class/footer.php');
?>
